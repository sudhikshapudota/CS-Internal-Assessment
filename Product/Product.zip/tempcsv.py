import sys, string, os
os.system("C:\Program Files (x86)\Melexis\MlxCIRT 90632\MlxCIRT.exe")

import csv
with open(r'C:\Users\computer\Desktop\Testing Env\mlxcirt3_log.csv') as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                answer = 0
                for column in csv_reader :
                           i = float(column[4])
                           if i > answer:
                               answer = i
print(answer)

