
var cancel = document.querySelector("#content i");

var mssage =document.querySelector("#mssage");

cancel.addEventListener('click',function(){
    mssage.style.top ="-1000px";
})