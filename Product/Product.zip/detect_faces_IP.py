﻿# USAGE
# python detect_faces_IP.py --prototxt deploy.prototxt.txt --model res10_300x300_ssd_iter_140000.caffemodel




# import the necessary packages
from imutils.video import VideoStream
import numpy as np
from ssl import SSLContext,PROTOCOL_TLSv1
from urllib.request import urlopen
import argparse
import imutils
import time
import cv2

# construct the argument parse and parse the arguments
#these arguments are to be entered into the command line while running the code. 

ap = argparse.ArgumentParser()
ap.add_argument("-p", "--prototxt", required=True,
	help="path to Caffe 'deploy' prototxt file")
ap.add_argument("-m", "--model", required=True,
	help="path to Caffe pre-trained model")
ap.add_argument("-c", "--confidence", type=float, default=0.5,
	help="minimum probability to filter weak detections")
args = vars(ap.parse_args())

# load our serialized model from disk
print("[INFO] loading model...")
net = cv2.dnn.readNetFromCaffe(args["prototxt"], args["model"])
print("[INFO] starting video stream...")

#cap.open("rtsp://admin:1234567a@192.168.1.65:554/doc/page/preview.asp")

# RTSP protocols usually have a URL of the form 
url1="rtsp://admin:1234567a@192.168.1.65:554/doc/page/preview.asp"
url2="rtsp://admin:1234567a@192.168.1.65:554/Streaming/Channels/<channel no><stream no>"
# channel number should be 101 by default
#stream number is not required as far as ive read
# Ex :  rtsp://admin:password@192.168.1.100:554/Streaming/Channels/101


cap = cv2.VideoCapture(url1)
#try url2 also


print(cap.isOpened())


while(cap.isOpened()):

	ret, frame = cap.read()

	if ret == False:
		break

	frame = imutils.resize(frame, width=400)
 
	# grab the frame dimensions and convert it to a blob
	(h, w) = frame.shape[:2]
	blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0,
		(300, 300), (104.0, 177.0, 123.0))
 
	# pass the blob through the network and obtain the detections and
	# predictions
	net.setInput(blob)
	detections = net.forward()

	# loop over the detections
	for i in range(0, detections.shape[2]):
		# extract the confidence (i.e., probability) associated with the
		# prediction
		confidence = detections[0, 0, i, 2]

		# filter out weak detections by ensuring the `confidence` is
		# greater than the minimum confidence
		if confidence < args["confidence"]:
			continue

		# compute the (x, y)-coordinates of the bounding box for the
		# object
		box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
		(startX, startY, endX, endY) = box.astype("int")
 
		# draw the bounding box of the face along with the associated
		# probability
		text = "{:.2f}%".format(confidence * 100)
		y = startY - 10 if startY - 10 > 10 else startY + 10
		cv2.rectangle(frame, (startX, startY), (endX, endY),
			(0, 0, 255), 2)
		cv2.putText(frame, text, (startX, y),
			cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)

	# show the output frame
	cv2.imshow("Frame", frame)
	key = cv2.waitKey(1) & 0xFF
 
	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
		break

# do a bit of cleanup
cap.release()
cv2.destroyAllWindows()
#vs.stop()



''' 

RTSP without Authentication (NVR/DVR/IPC/Encoder) 
rtsp://<IP address of device>:<RTSP port>/Streaming/channels/<channel number><stream number> 
NOTE: <stream number> represents main stream (01), or the sub stream (02) 
 
Example: rtsp://173.200.91.70:10554/Streaming/channels/101 – get the main stream of the 1st channel 
rtsp://173.200.91.70:10554/Streaming/channels/102 – get the sub stream of the 1st channel 
 
RTSP with Authentication 
rtsp://<username>:<password>@<IP address of device>:<RTSP port>/Streaming/channels/<channel number><stream number> 
 
Example: 
rtsp://Hikvision:guest@173.200.91.70:10554/Streaming/channels/1701 – get the main stream of the 17th channel  
(1st IP camera on the Hybrid Demo) 
rtsp://Hikvision:guest@173.200.91.70:10554/Streaming/channels/1902 – get the sub stream of the 19th channel  

'''